import 'package:flutter/material.dart';

class SearchService extends StatelessWidget {
  const SearchService({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
