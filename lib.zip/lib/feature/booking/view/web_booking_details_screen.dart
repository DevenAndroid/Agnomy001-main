import 'dart:developer';

import 'package:demandium/components/core_export.dart';
import 'package:demandium/feature/booking/widget/booking_otp_widget.dart';
import 'package:demandium/feature/booking/widget/booking_screen_shimmer.dart';
import 'package:demandium/feature/booking/widget/booking_summery_widget.dart';
import 'package:get/get.dart';

class WebBookingDetailsScreen extends StatelessWidget {
  final TabController? tabController;
  const WebBookingDetailsScreen({Key? key, this.tabController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FooterBaseView(
        child: GetBuilder<BookingDetailsController>(
            builder: (bookingDetailsController) {
          if (bookingDetailsController.bookingDetailsContent != null) {
            return Center(
              child: SizedBox(
                width: Dimensions.webMaxWidth,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BookingDetailsTopCard(
                        bookingDetailsContent:
                            bookingDetailsController.bookingDetailsContent!),
                    BookingTabBar(tabController: tabController),
                    SizedBox(
                      height: 650,
                      child: TabBarView(controller: tabController, children: [
                        WebBookingDetailsSection(
                          bookingDetailsContent:
                              bookingDetailsController.bookingDetailsContent!,
                        ),
                        const BookingHistory()
                      ]),
                    ),
                  ],
                ),
              ),
            );
          } else {
            return const Center(
                child: SizedBox(
                    width: Dimensions.webMaxWidth,
                    child: BookingScreenShimmer()));
          }
        }),
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      // floatingActionButton: Get.find<AuthController>().isLoggedIn()
      //     ? GetBuilder<BookingDetailsController>(
      //     builder: (bookingDetailsController) {
      //       if (bookingDetailsController.bookingDetailsContent != null) {
      //         return Column(
      //             crossAxisAlignment: CrossAxisAlignment.end,
      //             children: [
      //               const Expanded(child: SizedBox()),
      //               Padding(
      //                 padding: const EdgeInsets.only(
      //                    bottom: Dimensions.paddingSizeDefault,
      //                   left: Dimensions.paddingSizeDefault,
      //                    right: Dimensions.paddingSizeDefault,
      //                 ),
      //                 child: Row(
      //                     mainAxisAlignment: MainAxisAlignment.end,
      //                     children: [
      //                       FloatingActionButton(
      //                           hoverColor: Colors.transparent,
      //                           elevation: 0.0,
      //                           backgroundColor:
      //                           Theme.of(context).colorScheme.primary,
      //                           onPressed: () {
      //                             BookingDetailsContent bookingDetailsContent =
      //                             bookingDetailsController
      //                                 .bookingDetailsContent!;
      //                             if (bookingDetailsContent.provider != null) {
      //                               showModalBottomSheet(
      //                                 useRootNavigator: true,
      //                                 isScrollControlled: true,
      //                                 backgroundColor: Colors.transparent,
      //                                 context: context,
      //                                 builder: (context) => CreateChannelDialog(
      //                                   customerID:
      //                                   bookingDetailsContent.customerId,
      //                                   providerId: bookingDetailsContent
      //                                       .provider?.userId,
      //                                   serviceManId: bookingDetailsContent
      //                                       .serviceman?.userId,
      //                                   referenceId: bookingDetailsContent
      //                                       .readableId
      //                                       .toString(),
      //                                 ),
      //                               );
      //                             } else {
      //                               customSnackBar(
      //                                   'provider_or_service_man_assigned'.tr);
      //                             }
      //                           },
      //                           child:Image.asset("assets/images/messageicon.png",height:26,color: Theme.of(context).primaryColorLight)
      //                         //Icon(Icons., color: Theme.of(context).primaryColorLight),
      //                       ),
      //                     ]),
      //               ),
      //               !ResponsiveHelper.isDesktop(context) &&
      //                   bookingDetailsController
      //                       .bookingDetailsContent!.bookingStatus ==
      //                       'completed'
      //                   ? Row(
      //                 children: [
      //                   Expanded(
      //                     child: CustomButton(
      //                       radius: 0,
      //                       buttonText: 'review'.tr,
      //                       onPressed: () {
      //                         showModalBottomSheet(
      //                           context: context,
      //                           useRootNavigator: true,
      //                           isScrollControlled: true,
      //                           backgroundColor: Colors.transparent,
      //                           builder: (context) =>
      //                               ReviewRecommendationDialog(
      //                                 id: bookingDetailsController
      //                                     .bookingDetailsContent!.id!,
      //                               ),
      //                         );
      //                       },
      //                     ),
      //                   ),
      //                   Container(
      //                     width: 3,
      //                     height: 50,
      //                     color: Theme.of(context).disabledColor,
      //                   ),
      //                   GetBuilder<ServiceBookingController>(
      //                       builder: (serviceBookingController) {
      //                         return Expanded(
      //                           child: serviceBookingController.isLoading
      //                               ? const Center(
      //                               child: CircularProgressIndicator())
      //                               : CustomButton(
      //                             radius: 0,
      //                             buttonText: 'rebook'.tr,
      //                             onPressed: () {
      //                               serviceBookingController
      //                                   .checkCartSubcategory(
      //                                   bookingDetailsController
      //                                       .bookingDetailsContent!
      //                                       .id!,
      //                                   bookingDetailsController
      //                                       .bookingDetailsContent!
      //                                       .subCategoryId!);
      //                             },
      //                           ),
      //                         );
      //                       }),
      //                 ],
      //               )
      //                   : const SizedBox()
      //             ]);
      //       } else {
      //         return const SizedBox();
      //       }
      //     })
      //     : null,
    );
  }
}

class BookingDetailsTopCard extends StatelessWidget {
  final BookingDetailsContent bookingDetailsContent;
  const BookingDetailsTopCard({Key? key, required this.bookingDetailsContent})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: ResponsiveHelper.isDesktop(context)
              ? Theme.of(context).colorScheme.primary.withOpacity(0.07)
              : Theme.of(context).cardColor,
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(Dimensions.radiusLarge),
            bottomRight: Radius.circular(Dimensions.radiusLarge),
          )),
      child: Column(
        children: [
          Gaps.verticalGapOf(Dimensions.paddingSizeExtraLarge),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${'booking'.tr} # ',
                style: ubuntuBold.copyWith(
                    fontSize: Dimensions.fontSizeLarge,
                    color: Theme.of(context).textTheme.bodyLarge!.color),
              ),
              Text(bookingDetailsContent.readableId!.toString(),
                  textDirection: TextDirection.ltr,
                  style:
                      ubuntuBold.copyWith(fontSize: Dimensions.fontSizeLarge)),
            ],
          ),
          Gaps.verticalGapOf(Dimensions.paddingSizeExtraSmall),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${'booking_place'.tr} : ',
                style: ubuntuMedium.copyWith(
                    fontSize: Dimensions.fontSizeDefault,
                    color: Theme.of(context).textTheme.bodyLarge!.color),
              ),
              Text(
                DateConverter.dateMonthYearTimeTwentyFourFormat(
                    DateConverter.isoUtcStringToLocalDate(
                        bookingDetailsContent.createdAt!.toString())),
                textDirection: TextDirection.ltr,
                style: ubuntuRegular.copyWith(
                    fontSize: Dimensions.fontSizeDefault),
              ),
            ],
          ),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),
          Gaps.verticalGapOf(Dimensions.paddingSizeExtraSmall),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "${'service_scheduled_date'.tr} : ",
                style: ubuntuMedium.copyWith(
                    fontSize: Dimensions.fontSizeDefault,
                    color: Theme.of(context).textTheme.bodyLarge!.color),
              ),
              Text(
                DateConverter.dateMonthYearTimeTwentyFourFormat(
                    DateTime.tryParse(bookingDetailsContent.serviceSchedule!)!),
                style: ubuntuRegular.copyWith(
                    fontSize: Dimensions.fontSizeDefault),
                textDirection: TextDirection.ltr,
              ),
            ],
          ),
          const SizedBox(
            height: Dimensions.paddingSizeSmall,
          ),
          SizedBox(
            width: Dimensions.webMaxWidth / 2,
            child: RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                text: '${'address'.tr} : ',
                style: ubuntuMedium.copyWith(
                  fontSize: Dimensions.fontSizeDefault,
                  color: Theme.of(context).textTheme.bodyLarge!.color,
                ),
                children: [
                  TextSpan(
                    text: bookingDetailsContent.serviceAddress != null
                        ? bookingDetailsContent.serviceAddress!.address!
                        : 'no_address_found'.tr,
                    style: ubuntuRegular.copyWith(
                        fontSize: Dimensions.fontSizeDefault),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: Dimensions.paddingSizeSmall,
          ),
          RichText(
            text: TextSpan(
              text: '${'booking_status'.tr} : ',
              style: ubuntuMedium.copyWith(
                  fontSize: Dimensions.fontSizeDefault,
                  color: Theme.of(context).textTheme.bodyLarge!.color),
              children: [
                TextSpan(
                    text: bookingDetailsContent.bookingStatus!.tr,
                    style: ubuntuMedium.copyWith(
                        fontSize: Dimensions.fontSizeDefault,
                        color: Theme.of(context).colorScheme.primary)),
              ],
            ),
          ),
          Gaps.verticalGapOf(Dimensions.paddingSizeDefault),



        ],
      ),
    );
  }
}

class WebBookingDetailsSection extends StatelessWidget {
  final BookingDetailsContent bookingDetailsContent;
  const WebBookingDetailsSection(
      {Key? key, required this.bookingDetailsContent})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            const SizedBox(height: Dimensions.paddingSizeDefault),
            bookingDetailsContent.provider != null
                ? Row(
              mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                                  height: 165,
                                  width: 285,
                                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(
                            Dimensions.radiusDefault),
                        border: Border.all(
                            color: Theme.of(context)
                                .hintColor
                                .withOpacity(0.3)),
                        boxShadow:
                        searchBoxShadow), //boxShadow: shadow),
                    child: Column(
                      children: [
                        Gaps.verticalGapOf(
                            Dimensions.paddingSizeDefault),
                        Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal:
                                Dimensions.paddingSizeDefault),
                            child: Text("provider_info".tr,
                                style: ubuntuMedium.copyWith(
                                    fontSize:
                                    Dimensions.fontSizeSmall,
                                    color: Theme.of(context)
                                        .textTheme
                                        .bodyLarge!
                                        .color!))),
                        Gaps.verticalGapOf(
                            Dimensions.paddingSizeSmall),
                        ClipRRect(
                          borderRadius: const BorderRadius.all(
                              Radius.circular(Dimensions
                                  .paddingSizeExtraLarge)),
                          child: SizedBox(
                            width: Dimensions.imageSize,
                            height: Dimensions.imageSize,
                            child: CustomImage(
                                image:
                                "${Get.find<SplashController>().configModel.content!.imageBaseUrl}/provider/logo/${bookingDetailsContent.provider?.logo}"),
                          ),
                        ),
                        Gaps.verticalGapOf(
                            Dimensions.paddingSizeExtraSmall),
                        Text(
                            "${bookingDetailsContent.provider?.companyName}",
                            style: ubuntuBold.copyWith(
                                fontSize:
                                Dimensions.fontSizeExtraSmall)),
                        Gaps.verticalGapOf(
                            Dimensions.paddingSizeExtraSmall),
                        Text(
                            "${bookingDetailsContent.provider?.companyPhone}",
                            style: ubuntuRegular.copyWith(
                                fontSize:
                                Dimensions.fontSizeExtraSmall)),
                        Gaps.verticalGapOf(
                            Dimensions.paddingSizeDefault),
                      ],
                    ),
                                  ),
                                ),
                    SizedBox(width: Get.width*0.06,),
                    CircleAvatar(maxRadius: 46,minRadius: 46,
                   backgroundColor: Colors.white,
                   child : Padding(
                     padding: const EdgeInsets.only(right: 4,bottom: 2),
                     child: ClipRRect(
                       borderRadius: BorderRadius.circular(46),
                       child: Get.find<AuthController>().isLoggedIn()
                           ? GetBuilder<BookingDetailsController>(
                           builder: (bookingDetailsController) {
                             if (bookingDetailsController.bookingDetailsContent != null) {
                               return Column(
                                   crossAxisAlignment: CrossAxisAlignment.end,
                                   children: [
                                     const Expanded(child: SizedBox()),
                                     Padding(
                                       padding: const EdgeInsets.only(
                                         bottom: Dimensions.paddingSizeDefault,
                                         left: Dimensions.paddingSizeDefault,
                                         right: Dimensions.paddingSizeDefault,
                                       ),
                                       child: Row(
                                           mainAxisAlignment: MainAxisAlignment.end,
                                           children: [
                                             FloatingActionButton(
                                                 hoverColor: Colors.transparent,
                                                 elevation: 0.0,
                                                 backgroundColor:
                                                 Theme.of(context).colorScheme.primary,
                                                 onPressed: () {
                                                   BookingDetailsContent bookingDetailsContent =
                                                   bookingDetailsController
                                                       .bookingDetailsContent!;
                                                   if (bookingDetailsContent.provider != null) {
                                                     showModalBottomSheet(
                                                       useRootNavigator: true,
                                                       isScrollControlled: true,
                                                       backgroundColor: Colors.transparent,
                                                       context: context,
                                                       builder: (context) => CreateChannelDialog(
                                                         customerID:
                                                         bookingDetailsContent.customerId,
                                                         providerId: bookingDetailsContent
                                                             .provider?.userId,
                                                         serviceManId: bookingDetailsContent
                                                             .serviceman?.userId,
                                                         referenceId: bookingDetailsContent
                                                             .readableId
                                                             .toString(),
                                                       ),
                                                     );
                                                   } else {
                                                     customSnackBar(
                                                         'provider_or_service_man_assigned'.tr);
                                                   }
                                                 },
                                                 child:Image.asset("assets/images/messageicon.png",height:26,color: Theme.of(context).primaryColorLight)
                                               //Icon(Icons., color: Theme.of(context).primaryColorLight),
                                             ),
                                           ]),
                                     ),
                                     !ResponsiveHelper.isDesktop(context) &&
                                         bookingDetailsController
                                             .bookingDetailsContent!.bookingStatus ==
                                             'completed'
                                         ? Row(
                                       children: [
                                         Expanded(
                                           child: CustomButton(
                                             radius: 0,
                                             buttonText: 'review'.tr,
                                             onPressed: () {
                                               showModalBottomSheet(
                                                 context: context,
                                                 useRootNavigator: true,
                                                 isScrollControlled: true,
                                                 backgroundColor: Colors.transparent,
                                                 builder: (context) =>
                                                     ReviewRecommendationDialog(
                                                       id: bookingDetailsController
                                                           .bookingDetailsContent!.id!,
                                                     ),
                                               );
                                             },
                                           ),
                                         ),
                                         Container(
                                           width: 3,
                                           height: 50,
                                           color: Theme.of(context).disabledColor,
                                         ),
                                         GetBuilder<ServiceBookingController>(
                                             builder: (serviceBookingController) {
                                               return Expanded(
                                                 child: serviceBookingController.isLoading
                                                     ? const Center(
                                                     child: CircularProgressIndicator())
                                                     : CustomButton(
                                                   radius: 0,
                                                   buttonText: 'rebook'.tr,
                                                   onPressed: () {
                                                     serviceBookingController
                                                         .checkCartSubcategory(
                                                         bookingDetailsController
                                                             .bookingDetailsContent!
                                                             .id!,
                                                         bookingDetailsController
                                                             .bookingDetailsContent!
                                                             .subCategoryId!);
                                                   },
                                                 ),
                                               );
                                             }),
                                       ],
                                     )
                                         : const SizedBox()
                                   ]);
                             } else {
                               return const SizedBox();
                             }
                           })
                           : null,
                     ),
                   )

      )
                  ],
                )
                : const SizedBox(),
            const SizedBox(height: Dimensions.paddingSizeDefault),
           // const SizedBox(width: Dimensions.paddingSizeDefault),
            BookingSummeryWidget(bookingDetailsContent: bookingDetailsContent),
            (Get.find<SplashController>()
                        .configModel
                        .content!
                        .confirmationOtpStatus! &&
                    (bookingDetailsContent.bookingStatus == "accepted" ||
                        bookingDetailsContent.bookingStatus == "ongoing"))
                ? BookingOtpWidget(
                    bookingDetailsContent: bookingDetailsContent)
                : const SizedBox(),
        
            (Get.find<SplashController>()
                        .configModel
                        .content!
                        .confirmationOtpStatus! &&
                    (bookingDetailsContent.bookingStatus == "accepted" ||
                        bookingDetailsContent.bookingStatus == "ongoing"))
                ? const SizedBox()
                : const SizedBox(height: Dimensions.paddingSizeEight),
        
            Container(
              decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  borderRadius:
                      BorderRadius.circular(Dimensions.radiusDefault),
                  border: Border.all(
                      color:
                          Theme.of(context).hintColor.withOpacity(0.3)),
                  boxShadow: searchBoxShadow), //boxShadow: shadow),
              padding: const EdgeInsets.symmetric(
                  horizontal: Dimensions.paddingSizeDefault,
                  vertical: Dimensions.paddingSizeSmall),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('payment_method'.tr,
                          style: ubuntuBold.copyWith(
                            fontSize: Dimensions.fontSizeSmall,
                            color: Theme.of(context)
                                .textTheme
                                .bodyLarge!
                                .color!,
                            decoration: TextDecoration.none,
                          )),
                      const SizedBox(height: Dimensions.radiusDefault),
                      bookingDetailsContent.isPaid == 0?
                      Text(""):
                      Text(bookingDetailsContent.paymentMethod!.tr,
                          style: ubuntuRegular.copyWith(
                              fontSize: Dimensions.fontSizeExtraSmall,
                              color: Theme.of(context)
                                  .textTheme
                                  .bodyLarge!
                                  .color!
                                  .withOpacity(0.6)),
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: Dimensions.radiusDefault),
                      bookingDetailsContent.isPaid == 0?
                          Text("")
                          :Text(
                          '${'transaction_id'.tr} : ${bookingDetailsContent.transactionId?.tr ?? ''}',
                          style: ubuntuRegular.copyWith(
                              fontSize: Dimensions.fontSizeExtraSmall,
                              color: Theme.of(context)
                                  .textTheme
                                  .bodyLarge!
                                  .color!
                                  .withOpacity(0.6)),
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                          '${bookingDetailsContent.isPaid == 0 ? 'unpaid'.tr : 'paid'.tr} ',
                          style: ubuntuMedium.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: bookingDetailsContent.isPaid == 0
                                  ? Theme.of(context).colorScheme.error
                                  : Colors.green,
                              decoration: TextDecoration.none)),
                      const SizedBox(
                          height: Dimensions.paddingSizeExtraLarge),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(PriceConverter.convertPrice(bookingDetailsContent.quoteOfferedPrice!.toDouble(), isShowLongPrice: true),
                            style: ubuntuBold.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color:
                                  Theme.of(context).colorScheme.primary,
                            )),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),
        
            //const BookingCancelButton(),
        
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [

                bookingDetailsContent.serviceman != null
                    ? SizedBox(
                        height: 165,
                        width: 285,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.all(
                                Radius.circular(
                                    Dimensions.paddingSizeExtraSmall)),
                            color: Theme.of(context)
                                .primaryColor
                                .withOpacity(0.05),
                          ),
                          child: Column(
                            children: [
                              Gaps.verticalGapOf(
                                  Dimensions.paddingSizeDefault),
                              Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal:
                                          Dimensions.paddingSizeDefault),
                                  child: Text("service_man_info".tr,
                                      style: ubuntuMedium.copyWith(
                                          fontSize:
                                              Dimensions.fontSizeSmall,
                                          color: Theme.of(context)
                                              .textTheme
                                              .bodyLarge!
                                              .color!))),
                              Gaps.verticalGapOf(
                                  Dimensions.paddingSizeSmall),
                              ClipRRect(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(Dimensions
                                        .paddingSizeExtraLarge)),
                                child: SizedBox(
                                  width: Dimensions.imageSize,
                                  height: Dimensions.imageSize,
                                  child: CustomImage(
                                      image:
                                          "${Get.find<SplashController>().configModel.content!.imageBaseUrl}/serviceman/profile/${bookingDetailsContent.serviceman?.user!.profileImage!}"),
                                ),
                              ),
                              Gaps.verticalGapOf(
                                  Dimensions.paddingSizeExtraSmall),
                              Text(
                                 bookingDetailsContent.serviceman!.user?.firstName == null
                                      ? "${bookingDetailsContent.serviceman!.user?.firstName} ${bookingDetailsContent.serviceman!.user?.lastName}"
                              :"",
                                  style: ubuntuBold.copyWith(
                                      fontSize:
                                          Dimensions.fontSizeExtraSmall)),
                              Gaps.verticalGapOf(
                                  Dimensions.paddingSizeExtraSmall),
                              Text(
                                  bookingDetailsContent.serviceman!.user!.phone==null?   "${bookingDetailsContent.serviceman!.user!.phone}"
                                  : "",
                                  style: ubuntuRegular.copyWith(
                                      fontSize:
                                          Dimensions.fontSizeExtraSmall)),
                              Gaps.verticalGapOf(
                                  Dimensions.paddingSizeDefault),
                            ],
                          ),
                        ),
                      )
                    : const SizedBox(),
              ],
            ),

            // const SizedBox(height: Dimensions.paddingSizeDefault),
            bookingDetailsContent.posts!= null &&   bookingDetailsContent.posts!.latestbid!= null
                ? Container(
                    decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(
                            Dimensions.radiusDefault),
                        border: Border.all(
                            color: Theme.of(context)
                                .hintColor
                                .withOpacity(0.3)),
                        boxShadow: searchBoxShadow), //boxShadow: shadow),
                    padding: const EdgeInsets.symmetric(
                        horizontal: Dimensions.paddingSizeDefault,
                        vertical: Dimensions.paddingSizeSmall),
                    child: Column(
                      children: [
                      Text("Service Provider Offer Info",
                          style:ubuntuBold.copyWith(fontSize: Dimensions.fontSizeExtraSmall)),
                        Gaps.verticalGapOf(Dimensions.paddingSizeDefault),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text("Provider Notes :-",
                                style: ubuntuMedium.copyWith(fontSize: Dimensions.fontSizeSmall,
                                    color: Theme.of(context).textTheme.bodyLarge!.color!)),
                            Container(
                              width: Get.width*0.626,
                              child: Text(bookingDetailsContent.posts!.latestbid!.providerNote ?? "",
                                  style: ubuntuMedium.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).textTheme.bodyLarge!.color!)),
                            ),

                          ],
                        ),
                      ],
                    ),
                  )
                // Row(
                //
                //  //mainAxisAlignment: MainAxisAlignment.start,
                //   //crossAxisAlignment: CrossAxisAlignment.start,
                //    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //   children: [
                //     SizedBox(
                //       height: 200, width:540,
                //       child: Container(
                //         width:double.infinity,
                //         decoration: BoxDecoration(color: Theme.of(context).cardColor , borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
                //             border: Border.all(color: Theme.of(context).hintColor.withOpacity(0.3)), boxShadow: searchBoxShadow
                //         ),
                //         child: Padding(
                //           padding: const EdgeInsets.symmetric(horizontal: 8),
                //           child: Column(
                //             crossAxisAlignment: CrossAxisAlignment.start,
                //             mainAxisAlignment:MainAxisAlignment.start,
                //             children: [
                //               Gaps.verticalGapOf(Dimensions.paddingSizeDefault),
                //               Padding(
                //                   padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                //                   child: Text("Service Provider Offer Info",
                //                       style:ubuntuBold.copyWith(fontSize: Dimensions.fontSizeExtraSmall))
                //               ),
                //               Gaps.verticalGapOf(Dimensions.paddingSizeSmall),
                //               Row(
                //                 children: [
                //                   Text("Provider Notes :-",
                //                       style: ubuntuMedium.copyWith(fontSize: Dimensions.fontSizeSmall,
                //                           color: Theme.of(context).textTheme.bodyLarge!.color!)),
                //
                //                   Text(bookingDetailsContent.posts!.latestbid!.providerNote ?? "",
                //                       style: ubuntuMedium.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).textTheme.bodyLarge!.color!)),
                //
                //                 ],
                //               )
                //
                //             ],
                //           ),
                //         ),
                //       ),
                //     ),
                //     SizedBox(height: 0,width: 0,)
                //   ],
                // )
                : SizedBox(),

            SizedBox(height: 20,)
          ],
        ),
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      // floatingActionButton: Get.find<AuthController>().isLoggedIn()
      //     ? GetBuilder<BookingDetailsController>(
      //         builder: (bookingDetailsController) {
      //         if (bookingDetailsController.bookingDetailsContent != null) {
      //           return Column(
      //               crossAxisAlignment: CrossAxisAlignment.end,
      //               children: [
      //                 const Expanded(child: SizedBox()),
      //                 Padding(
      //                   padding: const EdgeInsets.only(
      //                    // bottom: Dimensions.paddingSizeDefault,
      //                     left: Dimensions.paddingSizeDefault,
      //                    // right: Dimensions.paddingSizeDefault,
      //                   ),
      //                   child: Row(
      //                       mainAxisAlignment: MainAxisAlignment.end,
      //                       children: [
      //                         FloatingActionButton(
      //                           hoverColor: Colors.transparent,
      //                           elevation: 0.0,
      //                           backgroundColor:
      //                               Theme.of(context).colorScheme.primary,
      //                           onPressed: () {
      //                             BookingDetailsContent bookingDetailsContent =
      //                                 bookingDetailsController
      //                                     .bookingDetailsContent!;
      //                             if (bookingDetailsContent.provider != null) {
      //                               showModalBottomSheet(
      //                                 useRootNavigator: true,
      //                                 isScrollControlled: true,
      //                                 backgroundColor: Colors.transparent,
      //                                 context: context,
      //                                 builder: (context) => CreateChannelDialog(
      //                                   customerID:
      //                                       bookingDetailsContent.customerId,
      //                                   providerId: bookingDetailsContent
      //                                       .provider?.userId,
      //                                   serviceManId: bookingDetailsContent
      //                                       .serviceman?.userId,
      //                                   referenceId: bookingDetailsContent
      //                                       .readableId
      //                                       .toString(),
      //                                 ),
      //                               );
      //                             } else {
      //                               customSnackBar(
      //                                   'provider_or_service_man_assigned'.tr);
      //                             }
      //                           },
      //                           child:Image.asset("assets/images/messageicon.png",height:26,color: Theme.of(context).primaryColorLight)
      //                           //Icon(Icons., color: Theme.of(context).primaryColorLight),
      //                         ),
      //                       ]),
      //                 ),
      //                 !ResponsiveHelper.isDesktop(context) &&
      //                         bookingDetailsController
      //                                 .bookingDetailsContent!.bookingStatus ==
      //                             'completed'
      //                     ? Row(
      //                         children: [
      //                           Expanded(
      //                             child: CustomButton(
      //                               radius: 0,
      //                               buttonText: 'review'.tr,
      //                               onPressed: () {
      //                                 showModalBottomSheet(
      //                                   context: context,
      //                                   useRootNavigator: true,
      //                                   isScrollControlled: true,
      //                                   backgroundColor: Colors.transparent,
      //                                   builder: (context) =>
      //                                       ReviewRecommendationDialog(
      //                                     id: bookingDetailsController
      //                                         .bookingDetailsContent!.id!,
      //                                   ),
      //                                 );
      //                               },
      //                             ),
      //                           ),
      //                           Container(
      //                             width: 3,
      //                             height: 50,
      //                             color: Theme.of(context).disabledColor,
      //                           ),
      //                           GetBuilder<ServiceBookingController>(
      //                               builder: (serviceBookingController) {
      //                             return Expanded(
      //                               child: serviceBookingController.isLoading
      //                                   ? const Center(
      //                                       child: CircularProgressIndicator())
      //                                   : CustomButton(
      //                                       radius: 0,
      //                                       buttonText: 'rebook'.tr,
      //                                       onPressed: () {
      //                                         serviceBookingController
      //                                             .checkCartSubcategory(
      //                                                 bookingDetailsController
      //                                                     .bookingDetailsContent!
      //                                                     .id!,
      //                                                 bookingDetailsController
      //                                                     .bookingDetailsContent!
      //                                                     .subCategoryId!);
      //                                       },
      //                                     ),
      //                             );
      //                           }),
      //                         ],
      //                       )
      //                     : const SizedBox()
      //               ]);
      //         } else {
      //           return const SizedBox();
      //         }
      //       })
      //     : null,
    );
  }
}
