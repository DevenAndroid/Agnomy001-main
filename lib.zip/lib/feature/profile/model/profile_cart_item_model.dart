class ProfileCardItemModel{
  final String title;
  final String loadingIcon;
  final String routeName;

  ProfileCardItemModel(this.title, this.loadingIcon, this.routeName);
}