import 'dart:math';

double degreeToRadian(double degrees) {
  return degrees * (pi / 180.0);
}